# Instalasi
1. Fork monsus lewat akun github masing-masing
2. Clone project yang udah difork
3. Install google api client "composer require google/apiclient:^2.0"

## Todo
1. Menambahkan framework yii keproject ini
2. Menambahkan fungsionalitas monitoring dulu lewat quickstart.php

Sepertinya sudah bisa jalan bareng-bareng yang design UI sama backendnya, nanti
tinggal pull request aja biar aku yang nyatuin.
